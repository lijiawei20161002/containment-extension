# Anonymous experiment supplement

Python 3.11+. Offline checks need pytest; E1 rendering also needs matplotlib. The native runner uses the standard library and hosted inference; no GPU is needed.

```sh
python3 -m pip install -e '.[dev]' matplotlib
python3 -m pytest -q
python3 scripts/draw_utility_incident_tradeoff.py
python3 scripts/run_feedback_ablation.py report results/feedback-ablation-v1
```

Archived E2 status: baseline_no_events. Do not mistake the scripted tests for model performance. The live run stopped at its predeclared baseline gate; selection, judge calibration and held-out stages were not reached. See the experiment report and frozen plan for exact budgets and schedules.

A fresh live replication requires an API key outside this archive, a new output directory, and a new authorization statement in a copied configuration. Never overwrite this evidence.

E5 contains blank independent-reader worksheets; no human agreement result is claimed. Send only results/incident-second-reader-v1/blind to the reader.

Public incident sources and synthetic .lab.test addresses are retained. Author identity metadata is removed only in exported copies. The transformation log and exported file hashes are in artifact-manifest.json. This is a local supplement; nothing was uploaded.
